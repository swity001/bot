<?php
$config = [
"imei" => "868199038359882",
"sign" => "6bf43e7e794f7d1d9c44c838ccc69ca99dae6213",
"token" => "e88cd5785289ca6473410db0ff7a324a",
"uuid" => "ea1bcdd3-436b-4cf7-aced-38bda50cfdbb"
];
